gg.toast('BOCAH NGAPA YAK ..')

::START::
menu = gg.choice({'•°Assasin°•','••°Author°•• + ~~EXIT~~'},nil,'Role Hero')
if menu == 1 then goto asa end
if menu == 2 then goto aut end
if menu == nil then goto START end
goto START

::aut::
gg.alert('MzRudy | FB : mzgamingrudy')
goto exit


::asa::
menu = gg.choice({'—‹Hayabusa','—‹Karina','—‹Natalia','—‹Lancelot','—‹Saber','—‹Helcurt','—‹Alucard','—‹Gusion'},nil,'Cheat No CoolDown')
if menu == 1 then goto OK1 end
if menu == 2 then goto OK2 end
if menu == 3 then goto OK3 end
if menu == 4 then goto OK4 end
if menu == 5 then goto OK5 end
if menu == 6 then goto OK6 end
if menu == 7 then goto OK7 end 
if menu == 8 then goto OK8 end
if menu == nil then print('Error') end
goto START

::OK1::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Hayabusa')
if menu == 1 then goto OKL1 end
if menu == 2 then goto OKL2 end
if menu == 3 then goto OKL3 end
if menu == nil then print('Error') end
goto exit

::OKL3::
gg.clearResults()
  gg.searchNumber("36000;130", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("32000;150", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("28000;170", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK1

::OKL2::
gg.clearResults()
  gg.searchNumber("18000;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("17000;90", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("16000;100", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("15000;110", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("14000;120", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("13000;130", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK3

::OKL1::
gg.clearResults()
  gg.searchNumber("7000;85", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("6500;95", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("6000;105", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("5500;115", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("5000;125", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("4500;135", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK1

::OK2::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Karina')
if menu == 1 then goto OKK1 end
if menu == 2 then goto OKK2 end
if menu == 3 then goto OKK3 end
if menu == nil then print('Error') end
goto exit

::OKK1::
gg.searchNumber('810;6000;60', gg.TYPE_DWORD)
gg.searchNumber('6000;60', TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('810;6000;65', gg.TYPE_DWORD)
gg.searchNumber('6000;65', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('810;6000;70', gg.TYPE_DWORD)
gg.searchNumber('6000;70', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('810;6000;75', gg.TYPE_DWORD)
gg.searchNumber('6000;75', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('810;6000;80', gg.TYPE_DWORD)
gg.searchNumber('6000;80', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('810;6000;85', gg.TYPE_DWORD)
gg.searchNumber('6000;85', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
goto OK2

::OKK2::
gg.clearResults()
gg.searchNumber('820;4500;60', gg.TYPE_DWORD)
gg.searchNumber('4500;60', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('820;4500;70', gg.TYPE_DWORD)
gg.searchNumber('4500;70', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('820;4500;80', gg.TYPE_DWORD)
gg.searchNumber('4500;80', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('820;4500;90', gg.TYPE_DWORD)
gg.searchNumber('4500;90', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('820;4500;100', gg.TYPE_DWORD)
gg.searchNumber('4500;100', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('820;4500;110', gg.TYPE_DWORD)
gg.searchNumber('4500;110', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
goto OK2

::OKK3::
gg.clearResults()
gg.searchNumber('830;36000;100', gg.TYPE_DWORD)
gg.searchNumber('36000;100', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('830;30000;120', gg.TYPE_DWORD)
gg.searchNumber('30000;120', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('830;24000;140', gg.TYPE_DWORD)
gg.searchNumber('24000;140', gg.TYPE_DWORD)
gg.getResults(100)
gg.clearResults()
gg.editAll('0', gg.TYPE_DWORD)
goto OK2

::OK3::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Natalia')
if menu == 1 then goto OKN1 end
if menu == 2 then goto OKN2 end
if menu == 3 then goto OKN3 end
if menu == nil then print('Error') end
goto exit

::OKN1::
gg.clearResults()
  gg.searchNumber("11000;50", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("10500;55", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("10000;60", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("9500;65", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("9000;70", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("8500;75", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK3

::OKN2::
gg.clearResults()
  gg.searchNumber("13500;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("13200;85", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("12900;90", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("12600;95", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("12300;100", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("12000;105", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK3

::OKN3::
gg.clearResults()
  gg.searchNumber("30000;110", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("24000;130", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("18000;150", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK3

::OK4::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Lancelot')
if menu == 1 then goto OKLA1 end
if menu == 2 then goto OKLA2 end
if menu == 3 then goto OKLA3 end
if menu == nil then print('Error') end
goto exit

::OKLA1::
gg.clearResults()
  gg.searchNumber("14000;50", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("13600;55", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("13200;65", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("12800;70", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("12400;75", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("12000;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK4

::OKLA2::
gg.clearResults()
  gg.searchNumber("8000;70", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("8000;75", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("8000;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("8000;85", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("8000;90", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("8000;95", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK4

::OKLA3::
gg.clearResults()
  gg.searchNumber("27000;100", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("24000;125", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("21000;150", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK4

::OK6::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Helcurt')
if menu == 1 then goto OKH1 end
if menu == 2 then goto OKH2 end
if menu == 3 then goto OKH3 end
if menu == nil then print('Error') end
goto exit

::OKH1::
gg.clearResults()
  gg.searchNumber("10000;60", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("9600;70", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("9200;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("8800;90", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("8400;100", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("8000;110", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK6

::OKH2::
gg.clearResults()
  gg.searchNumber("4000;70", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("4000;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("4000;90", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("4000;100", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("4000;110", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("4000;120", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK6

::OKH3::
gg.clearResults()
  gg.searchNumber("60000;120", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("60000;140", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("60000;160", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK6


::OK5::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Saber')
if menu == 1 then goto OKS1 end
if menu == 2 then goto OKS2 end
if menu == 3 then goto OKS3 end
if menu == nil then print('Error') end
goto exit

::OKS1::
gg.clearResults()
gg.searchNumber('310;8000;80', gg.TYPE_DWORD)
gg.searchNumber('8000;80', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('310;8000;95', gg.TYPE_DWORD)
gg.searchNumber('8000;95', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('310;8000;110', gg.TYPE_DWORD)
gg.searchNumber('8000;110', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('310;8000;125', gg.TYPE_DWORD)
gg.searchNumber('8000;125', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('310;8000;140', gg.TYPE_DWORD)
gg.searchNumber('8000;140', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('310;8000;155', gg.TYPE_DWORD)
gg.searchNumber('8000;155', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.toast('SUCCESS!!')
goto OK5

::OKS2::
gg.clearResults()
gg.searchNumber('320;14000;70', gg.TYPE_DWORD)
gg.searchNumber('14000;70', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('320;13000;80', gg.TYPE_DWORD)
gg.searchNumber('13000;80', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('320;12000;90', gg.TYPE_DWORD)
gg.searchNumber('12000;90', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('320;11000;100', gg.TYPE_DWORD)
gg.searchNumber('11000;100', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('320;10000;110', gg.TYPE_DWORD)
gg.searchNumber('10000;110', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('320;9000;120', gg.TYPE_DWORD)
gg.searchNumber('9000;120', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.toast('SUCCESS!!')
goto OK5

::OKS3::
gg.clearResults()
gg.searchNumber('330;34000;100', gg.TYPE_DWORD)
gg.searchNumber('34000;100', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('330;30000;120', gg.TYPE_DWORD)
gg.searchNumber('30000;120', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('330;26000;140', gg.TYPE_DWORD)
gg.searchNumber('26000;140', gg.TYPE_DWORD)
gg.getResults(100)
gg.clearResults()
gg.editAll('0', gg.TYPE_DWORD)
gg.toast('SUCCESS!!')
goto OK5

::OK7::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Alucard')
if menu == 1 then goto OKA1 end
if menu == 2 then goto OKA2 end
if menu == 3 then goto OKA3 end
if menu == nil then print('Error') end
goto exit

::OKA1::
gg.clearResults()
gg.searchNumber('10000;33;132', gg.TYPE_DWORD)
gg.searchNumber('10000', TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('9500;33;132', gg.TYPE_DWORD)
gg.searchNumber('9500', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('9000;33;132', gg.TYPE_DWORD)
gg.searchNumber('9000', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('8500;33;132', gg.TYPE_DWORD)
gg.searchNumber('8500', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('8000;33;132', gg.TYPE_DWORD)
gg.searchNumber('8000', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('7500;33;132', gg.TYPE_DWORD)
gg.searchNumber('7500', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
goto OK7

::OKA2::
gg.clearResults()
gg.searchNumber('5000;720;1000', gg.TYPE_DWORD)
gg.searchNumber('5000', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
goto OK7

::OKA3::
gg.clearResults()
gg.searchNumber('30000;25000', gg.TYPE_DWORD)
gg.searchNumber('30000;25000', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('20000;100;132', gg.TYPE_DWORD)
gg.searchNumber('20000', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
goto OK7

::OK8::
menu = gg.choice({'SKILL 1','SKILL 2','SKILL 3'},nil,'Gusion')
if menu == 1 then goto OKG1 end
if menu == 2 then goto OKG2 end
if menu == 3 then goto OKG3 end
if menu == nil then print('Error') end
goto exit

::OKG1::
gg.clearResults()
  gg.searchNumber("9000;70", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("8400;75", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("7800;80", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("7200;85", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("6600;90", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("6000;95", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
goto OK8

::OKG2::
gg.clearResults()
  gg.searchNumber("11000;65", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("10600;75", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("10200;85", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("9800;95", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
  gg.clearResults()
  gg.searchNumber("9400;105", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
gg.clearResults()
  gg.searchNumber("9000;115", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults('100')
  gg.editAll("0", gg.TYPE_DWORD)
goto OK8

::OKG3::
gg.clearResults()
gg.searchNumber('28000;100', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('24000;50', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
gg.clearResults()
gg.searchNumber('20000;5630', gg.TYPE_DWORD)
gg.searchNumber('20000', gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll('0', gg.TYPE_DWORD)
goto OK8

::exit:: 
gg.toast('Wkwkwkwk')
print('FB : Mzgamingrudy')
print('Follow INSTAGRAM : Mzgamingrudy')
print('YT : MzRudy Gaming')
os.exit()

